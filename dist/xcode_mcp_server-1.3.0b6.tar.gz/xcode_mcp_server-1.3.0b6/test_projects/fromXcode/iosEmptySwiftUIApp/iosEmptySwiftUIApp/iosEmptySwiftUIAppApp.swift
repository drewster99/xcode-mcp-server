//
//  iosEmptySwiftUIAppApp.swift
//  iosEmptySwiftUIApp
//
//  Created by Andrew Benson on 9/30/25.
//

import SwiftUI

@main
struct iosEmptySwiftUIAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
