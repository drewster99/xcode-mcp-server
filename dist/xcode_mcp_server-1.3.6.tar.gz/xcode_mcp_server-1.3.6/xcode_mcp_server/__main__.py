#!/usr/bin/env python3
"""Xcode MCP Server - Main entry point for python -m"""

from xcode_mcp_server import main

if __name__ == "__main__":
    main()
