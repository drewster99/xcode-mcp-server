#!/bin/sh
cd /Users/andrew/cursor/xcode-mcp-server
exec /opt/homebrew/Caskroom/miniconda/base/envs/xcode-mcp-dev/bin/python -m xcode_mcp_server
