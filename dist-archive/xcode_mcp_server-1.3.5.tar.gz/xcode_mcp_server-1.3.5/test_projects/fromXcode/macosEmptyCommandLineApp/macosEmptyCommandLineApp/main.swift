//
//  main.swift
//  macosEmptyCommandLineApp
//
//  Created by Andrew Benson on 9/30/25.
//

import Foundation

print("Hello, World!")

