//
//  macosEmptySwiftUIAppApp.swift
//  macosEmptySwiftUIApp
//
//  Created by Andrew Benson on 9/30/25.
//

import SwiftUI

@main
struct macosEmptySwiftUIAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
